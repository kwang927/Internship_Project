2021-08-18 08:56:01,352 [http-nio-8090-exec-7] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-08-18 08:56:01,378 [http-nio-8090-exec-7] ==> Parameters: admin(String)
2021-08-18 08:56:01,394 [http-nio-8090-exec-7] <==      Total: 1
2021-08-18 08:56:01,425 [http-nio-8090-exec-7] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-08-18 08:56:01,426 [http-nio-8090-exec-7] ==> Parameters: 1(Long)
2021-08-18 08:56:01,444 [http-nio-8090-exec-7] <==      Total: 43
2021-08-18 08:56:01,597 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 08:56:01,622 [taskExecutor-1] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-08-18 08:56:01,627 [taskExecutor-1] <==    Updates: 1
2021-08-18 08:56:02,145 [http-nio-8090-exec-4] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 08:56:02,147 [http-nio-8090-exec-4] ==> Parameters: 1(Long)
2021-08-18 08:56:02,151 [http-nio-8090-exec-4] <==      Total: 1
2021-08-18 09:01:16,857 [http-nio-8090-exec-6] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:01:16,876 [http-nio-8090-exec-6] ==> Parameters: 1(Long)
2021-08-18 09:01:16,898 [http-nio-8090-exec-6] <==      Total: 1
2021-08-18 09:04:57,256 [http-nio-8090-exec-6] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:04:57,281 [http-nio-8090-exec-6] ==> Parameters: 1(Long)
2021-08-18 09:04:57,300 [http-nio-8090-exec-6] <==      Total: 1
2021-08-18 09:09:15,148 [http-nio-8090-exec-6] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:09:15,163 [http-nio-8090-exec-6] ==> Parameters: 1(Long)
2021-08-18 09:09:15,176 [http-nio-8090-exec-6] <==      Total: 1
2021-08-18 09:09:17,106 [http-nio-8090-exec-10] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-08-18 09:09:17,107 [http-nio-8090-exec-10] ==> Parameters: 
2021-08-18 09:09:17,123 [http-nio-8090-exec-10] <==      Total: 43
2021-08-18 09:10:04,731 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 09:10:04,748 [taskExecutor-1] ==> Parameters: 1(Long), 生成代码(String), true(Boolean), null
2021-08-18 09:10:04,751 [taskExecutor-1] <==    Updates: 1
2021-08-18 09:12:58,752 [http-nio-8090-exec-8] ==>  Preparing: select * from sys_permission t where t.type = 1 order by t.sort 
2021-08-18 09:12:58,754 [http-nio-8090-exec-8] ==> Parameters: 
2021-08-18 09:12:58,764 [http-nio-8090-exec-8] <==      Total: 20
2021-08-18 09:13:39,331 [http-nio-8090-exec-10] ==>  Preparing: insert into sys_permission(parentId, name, css, href, type, permission, sort) values(?, ?, ?, ?, ?, ?, ?) 
2021-08-18 09:13:39,335 [http-nio-8090-exec-10] ==> Parameters: 0(Long), newTree(String), (String), pages/newTree/testTreeExampleList.html(String), 1(Integer), (String), 100(Integer)
2021-08-18 09:13:39,341 [http-nio-8090-exec-10] <==    Updates: 1
2021-08-18 09:13:39,343 [taskExecutor-2] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 09:13:39,346 [taskExecutor-2] ==> Parameters: 1(Long), 保存菜单(String), true(Boolean), null
2021-08-18 09:13:39,350 [taskExecutor-2] <==    Updates: 1
2021-08-18 09:13:40,749 [http-nio-8090-exec-4] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-08-18 09:13:40,750 [http-nio-8090-exec-4] ==> Parameters: 
2021-08-18 09:13:40,768 [http-nio-8090-exec-4] <==      Total: 44
2021-08-18 09:13:44,021 [http-nio-8090-exec-8] ==>  Preparing: select count(1) from sys_role t 
2021-08-18 09:13:44,025 [http-nio-8090-exec-8] ==> Parameters: 
2021-08-18 09:13:44,032 [http-nio-8090-exec-8] <==      Total: 1
2021-08-18 09:13:44,036 [http-nio-8090-exec-8] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-08-18 09:13:44,037 [http-nio-8090-exec-8] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 09:13:44,041 [http-nio-8090-exec-8] <==      Total: 2
2021-08-18 09:13:50,343 [http-nio-8090-exec-10] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-08-18 09:13:50,344 [http-nio-8090-exec-10] ==> Parameters: 
2021-08-18 09:13:50,349 [http-nio-8090-exec-10] <==      Total: 44
2021-08-18 09:13:50,516 [http-nio-8090-exec-2] ==>  Preparing: select * from sys_role t where t.id = ? 
2021-08-18 09:13:50,517 [http-nio-8090-exec-2] ==> Parameters: 1(Long)
2021-08-18 09:13:50,522 [http-nio-8090-exec-2] <==      Total: 1
2021-08-18 09:13:50,566 [http-nio-8090-exec-4] ==>  Preparing: select p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId where rp.roleId = ? order by p.sort 
2021-08-18 09:13:50,579 [http-nio-8090-exec-4] ==> Parameters: 1(Long)
2021-08-18 09:13:50,591 [http-nio-8090-exec-4] <==      Total: 43
2021-08-18 09:13:55,780 [http-nio-8090-exec-6] ==>  Preparing: select * from sys_role t where t.name = ? 
2021-08-18 09:13:55,781 [http-nio-8090-exec-6] ==> Parameters: ADMIN(String)
2021-08-18 09:13:55,788 [http-nio-8090-exec-6] <==      Total: 1
2021-08-18 09:13:55,789 [http-nio-8090-exec-6] ==>  Preparing: update sys_role t set t.name = ?, t.description = ?, updateTime = now() where t.id = ? 
2021-08-18 09:13:55,792 [http-nio-8090-exec-6] ==> Parameters: ADMIN(String), 管理员(String), 1(Long)
2021-08-18 09:13:55,795 [http-nio-8090-exec-6] <==    Updates: 1
2021-08-18 09:13:55,795 [http-nio-8090-exec-6] ==>  Preparing: delete from sys_role_permission where roleId = ? 
2021-08-18 09:13:55,795 [http-nio-8090-exec-6] ==> Parameters: 1(Long)
2021-08-18 09:13:55,797 [http-nio-8090-exec-6] <==    Updates: 43
2021-08-18 09:13:55,804 [http-nio-8090-exec-6] ==>  Preparing: insert into sys_role_permission(roleId, permissionId) values (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) , (?, ?) 
2021-08-18 09:13:55,808 [http-nio-8090-exec-6] ==> Parameters: 1(Long), 1(Long), 1(Long), 2(Long), 1(Long), 4(Long), 1(Long), 3(Long), 1(Long), 43(Long), 1(Long), 7(Long), 1(Long), 8(Long), 1(Long), 11(Long), 1(Long), 10(Long), 1(Long), 9(Long), 1(Long), 12(Long), 1(Long), 15(Long), 1(Long), 14(Long), 1(Long), 13(Long), 1(Long), 41(Long), 1(Long), 42(Long), 1(Long), 6(Long), 1(Long), 16(Long), 1(Long), 18(Long), 1(Long), 17(Long), 1(Long), 21(Long), 1(Long), 22(Long), 1(Long), 23(Long), 1(Long), 24(Long), 1(Long), 25(Long), 1(Long), 26(Long), 1(Long), 27(Long), 1(Long), 28(Long), 1(Long), 29(Long), 1(Long), 30(Long), 1(Long), 31(Long), 1(Long), 32(Long), 1(Long), 33(Long), 1(Long), 34(Long), 1(Long), 35(Long), 1(Long), 36(Long), 1(Long), 37(Long), 1(Long), 38(Long), 1(Long), 39(Long), 1(Long), 40(Long), 1(Long), 19(Long), 1(Long), 20(Long), 1(Long), 44(Long), 1(Long), 45(Long)
2021-08-18 09:13:55,811 [http-nio-8090-exec-6] <==    Updates: 44
2021-08-18 09:13:55,815 [taskExecutor-3] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 09:13:55,821 [taskExecutor-3] ==> Parameters: 1(Long), 保存角色(String), true(Boolean), null
2021-08-18 09:13:55,824 [taskExecutor-3] <==    Updates: 1
2021-08-18 09:13:57,203 [http-nio-8090-exec-10] ==>  Preparing: select count(1) from sys_role t 
2021-08-18 09:13:57,204 [http-nio-8090-exec-10] ==> Parameters: 
2021-08-18 09:13:57,210 [http-nio-8090-exec-10] <==      Total: 1
2021-08-18 09:13:57,211 [http-nio-8090-exec-10] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-08-18 09:13:57,211 [http-nio-8090-exec-10] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 09:13:57,215 [http-nio-8090-exec-10] <==      Total: 2
2021-08-18 09:13:58,008 [taskExecutor-4] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 09:13:58,010 [taskExecutor-4] ==> Parameters: 1(Long), 退出(String), true(Boolean), null
2021-08-18 09:13:58,013 [taskExecutor-4] <==    Updates: 1
2021-08-18 09:13:58,679 [http-nio-8090-exec-3] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-08-18 09:13:58,681 [http-nio-8090-exec-3] ==> Parameters: admin(String)
2021-08-18 09:13:58,685 [http-nio-8090-exec-3] <==      Total: 1
2021-08-18 09:13:58,711 [http-nio-8090-exec-3] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-08-18 09:13:58,711 [http-nio-8090-exec-3] ==> Parameters: 1(Long)
2021-08-18 09:13:58,717 [http-nio-8090-exec-3] <==      Total: 44
2021-08-18 09:13:58,827 [taskExecutor-5] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 09:13:58,828 [taskExecutor-5] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-08-18 09:13:58,836 [taskExecutor-5] <==    Updates: 1
2021-08-18 09:13:58,996 [http-nio-8090-exec-9] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:13:58,999 [http-nio-8090-exec-9] ==> Parameters: 1(Long)
2021-08-18 09:13:59,005 [http-nio-8090-exec-9] <==      Total: 1
2021-08-18 09:14:55,173 [http-nio-8090-exec-9] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:14:55,197 [http-nio-8090-exec-9] ==> Parameters: 1(Long)
2021-08-18 09:14:55,209 [http-nio-8090-exec-9] <==      Total: 1
2021-08-18 09:14:57,422 [http-nio-8090-exec-3] ==>  Preparing: select count(1) from testTreeExample t 
2021-08-18 09:14:57,423 [http-nio-8090-exec-3] ==> Parameters: 
2021-08-18 09:14:57,429 [http-nio-8090-exec-3] <==      Total: 1
2021-08-18 09:14:57,432 [http-nio-8090-exec-3] ==>  Preparing: select * from testTreeExample t order by content asc limit ?, ? 
2021-08-18 09:14:57,433 [http-nio-8090-exec-3] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 09:14:57,440 [http-nio-8090-exec-3] <==      Total: 10
2021-08-18 09:15:59,580 [http-nio-8090-exec-9] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:15:59,581 [http-nio-8090-exec-9] ==> Parameters: 1(Long)
2021-08-18 09:15:59,584 [http-nio-8090-exec-9] <==      Total: 1
2021-08-18 09:16:05,330 [http-nio-8090-exec-3] ==>  Preparing: select * from testTreeExample t order by t.sort 
2021-08-18 09:16:05,330 [http-nio-8090-exec-3] ==> Parameters: 
2021-08-18 09:16:05,333 [http-nio-8090-exec-3] <==      Total: 12
2021-08-18 09:45:46,624 [http-nio-8090-exec-9] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:45:46,627 [http-nio-8090-exec-9] ==> Parameters: 1(Long)
2021-08-18 09:45:46,629 [http-nio-8090-exec-9] <==      Total: 1
2021-08-18 09:45:47,623 [http-nio-8090-exec-3] ==>  Preparing: select count(1) from oneToMany t 
2021-08-18 09:45:47,624 [http-nio-8090-exec-3] ==> Parameters: 
2021-08-18 09:45:47,627 [http-nio-8090-exec-3] <==      Total: 1
2021-08-18 09:45:47,628 [http-nio-8090-exec-3] ==>  Preparing: select * from oneToMany t order by id asc limit ?, ? 
2021-08-18 09:45:47,628 [http-nio-8090-exec-3] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 09:45:47,631 [http-nio-8090-exec-3] <==      Total: 4
2021-08-18 09:45:54,024 [http-nio-8090-exec-1] ==>  Preparing: select count(1) from oneToMany t WHERE id = ? 
2021-08-18 09:45:54,026 [http-nio-8090-exec-1] ==> Parameters: 2(String)
2021-08-18 09:45:54,029 [http-nio-8090-exec-1] <==      Total: 1
2021-08-18 09:55:03,713 [http-nio-8090-exec-10] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 09:55:03,718 [http-nio-8090-exec-10] ==> Parameters: 1(Long)
2021-08-18 09:55:03,722 [http-nio-8090-exec-10] <==      Total: 1
2021-08-18 13:57:54,511 [http-nio-8090-exec-3] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-08-18 13:57:54,514 [http-nio-8090-exec-3] ==> Parameters: admin(String)
2021-08-18 13:57:54,524 [http-nio-8090-exec-3] <==      Total: 1
2021-08-18 13:57:54,573 [http-nio-8090-exec-3] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-08-18 13:57:54,574 [http-nio-8090-exec-3] ==> Parameters: 1(Long)
2021-08-18 13:57:54,588 [http-nio-8090-exec-3] <==      Total: 44
2021-08-18 13:57:54,770 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 13:57:54,782 [taskExecutor-1] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-08-18 13:57:54,793 [taskExecutor-1] <==    Updates: 1
2021-08-18 13:57:54,971 [http-nio-8090-exec-9] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 13:57:54,975 [http-nio-8090-exec-9] ==> Parameters: 1(Long)
2021-08-18 13:57:54,982 [http-nio-8090-exec-9] <==      Total: 1
2021-08-18 13:58:04,937 [http-nio-8090-exec-3] ==>  Preparing: select count(1) from oneToMany t 
2021-08-18 13:58:04,938 [http-nio-8090-exec-3] ==> Parameters: 
2021-08-18 13:58:04,941 [http-nio-8090-exec-3] <==      Total: 1
2021-08-18 13:58:04,950 [http-nio-8090-exec-3] ==>  Preparing: select * from oneToMany t order by id asc limit ?, ? 
2021-08-18 13:58:04,952 [http-nio-8090-exec-3] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 13:58:04,955 [http-nio-8090-exec-3] <==      Total: 4
2021-08-18 13:58:10,719 [http-nio-8090-exec-1] ==>  Preparing: select count(1) from oneToMany t WHERE userId = ? 
2021-08-18 13:58:10,722 [http-nio-8090-exec-1] ==> Parameters: 1(String)
2021-08-18 13:58:10,726 [http-nio-8090-exec-1] <==      Total: 1
2021-08-18 13:58:10,729 [http-nio-8090-exec-1] ==>  Preparing: select * from oneToMany t WHERE userId = ? order by id asc limit ?, ? 
2021-08-18 13:58:10,731 [http-nio-8090-exec-1] ==> Parameters: 1(String), 0(Integer), 10(Integer)
2021-08-18 13:58:10,734 [http-nio-8090-exec-1] <==      Total: 2
2021-08-18 13:58:13,933 [http-nio-8090-exec-9] ==>  Preparing: select count(1) from oneToMany t 
2021-08-18 13:58:13,934 [http-nio-8090-exec-9] ==> Parameters: 
2021-08-18 13:58:13,937 [http-nio-8090-exec-9] <==      Total: 1
2021-08-18 13:58:13,937 [http-nio-8090-exec-9] ==>  Preparing: select * from oneToMany t order by id asc limit ?, ? 
2021-08-18 13:58:13,942 [http-nio-8090-exec-9] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 13:58:13,944 [http-nio-8090-exec-9] <==      Total: 4
2021-08-18 13:58:18,613 [http-nio-8090-exec-3] ==>  Preparing: select * from testTreeExample t order by t.sort 
2021-08-18 13:58:18,615 [http-nio-8090-exec-3] ==> Parameters: 
2021-08-18 13:58:18,630 [http-nio-8090-exec-3] <==      Total: 12
2021-08-18 14:33:36,980 [http-nio-8090-exec-8] ==>  Preparing: select count(1) from file_info t 
2021-08-18 14:33:36,981 [http-nio-8090-exec-8] ==> Parameters: 
2021-08-18 14:33:36,987 [http-nio-8090-exec-8] <==      Total: 1
2021-08-18 14:33:36,993 [http-nio-8090-exec-8] ==>  Preparing: select * from file_info t order by updateTime desc limit ?, ? 
2021-08-18 14:33:36,994 [http-nio-8090-exec-8] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 14:33:36,997 [http-nio-8090-exec-8] <==      Total: 5
2021-08-18 14:35:51,752 [taskExecutor-2] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:35:51,766 [taskExecutor-2] ==> Parameters: 1(Long), 根据sql在页面显示结果(String), true(Boolean), null
2021-08-18 14:35:51,773 [taskExecutor-2] <==    Updates: 1
2021-08-18 14:35:59,795 [taskExecutor-3] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:35:59,817 [taskExecutor-3] ==> Parameters: 1(Long), 根据sql导出excel(String), true(Boolean), null
2021-08-18 14:35:59,829 [taskExecutor-3] <==    Updates: 1
2021-08-18 14:37:23,607 [http-nio-8090-exec-6] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 14:37:23,651 [http-nio-8090-exec-6] ==> Parameters: 1(Long)
2021-08-18 14:37:23,680 [http-nio-8090-exec-6] <==      Total: 1
2021-08-18 14:37:41,010 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:37:41,039 [taskExecutor-1] ==> Parameters: 1(Long), 根据sql在页面显示结果(String), true(Boolean), null
2021-08-18 14:37:41,042 [taskExecutor-1] <==    Updates: 1
2021-08-18 14:37:44,320 [taskExecutor-2] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:37:44,336 [taskExecutor-2] ==> Parameters: 1(Long), 根据sql导出excel(String), true(Boolean), null
2021-08-18 14:37:44,342 [taskExecutor-2] <==    Updates: 1
2021-08-18 14:38:47,971 [http-nio-8090-exec-2] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-08-18 14:38:47,992 [http-nio-8090-exec-2] ==> Parameters: admin(String)
2021-08-18 14:38:48,007 [http-nio-8090-exec-2] <==      Total: 1
2021-08-18 14:38:48,030 [http-nio-8090-exec-2] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-08-18 14:38:48,032 [http-nio-8090-exec-2] ==> Parameters: 1(Long)
2021-08-18 14:38:48,047 [http-nio-8090-exec-2] <==      Total: 44
2021-08-18 14:38:48,204 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:38:48,221 [taskExecutor-1] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-08-18 14:38:48,229 [taskExecutor-1] <==    Updates: 1
2021-08-18 14:38:48,600 [http-nio-8090-exec-8] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 14:38:48,608 [http-nio-8090-exec-8] ==> Parameters: 1(Long)
2021-08-18 14:38:48,613 [http-nio-8090-exec-8] <==      Total: 1
2021-08-18 14:39:00,041 [taskExecutor-2] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:39:00,049 [taskExecutor-2] ==> Parameters: 1(Long), 根据sql在页面显示结果(String), true(Boolean), null
2021-08-18 14:39:00,054 [taskExecutor-2] <==    Updates: 1
2021-08-18 14:39:02,038 [taskExecutor-3] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:39:02,049 [taskExecutor-3] ==> Parameters: 1(Long), 根据sql导出excel(String), true(Boolean), null
2021-08-18 14:39:02,051 [taskExecutor-3] <==    Updates: 1
2021-08-18 14:40:16,243 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:40:16,304 [taskExecutor-1] ==> Parameters: 1(Long), 退出(String), true(Boolean), null
2021-08-18 14:40:16,320 [taskExecutor-1] <==    Updates: 1
2021-08-18 14:40:17,710 [http-nio-8090-exec-3] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-08-18 14:40:17,712 [http-nio-8090-exec-3] ==> Parameters: admin(String)
2021-08-18 14:40:17,739 [http-nio-8090-exec-3] <==      Total: 1
2021-08-18 14:40:17,770 [http-nio-8090-exec-3] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-08-18 14:40:17,771 [http-nio-8090-exec-3] ==> Parameters: 1(Long)
2021-08-18 14:40:17,787 [http-nio-8090-exec-3] <==      Total: 44
2021-08-18 14:40:17,925 [taskExecutor-2] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:40:17,926 [taskExecutor-2] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-08-18 14:40:17,931 [taskExecutor-2] <==    Updates: 1
2021-08-18 14:40:18,325 [http-nio-8090-exec-9] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 14:40:18,327 [http-nio-8090-exec-9] ==> Parameters: 1(Long)
2021-08-18 14:40:18,331 [http-nio-8090-exec-9] <==      Total: 1
2021-08-18 14:40:23,998 [taskExecutor-3] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 14:40:24,017 [taskExecutor-3] ==> Parameters: 1(Long), 根据sql导出excel(String), true(Boolean), null
2021-08-18 14:40:24,021 [taskExecutor-3] <==    Updates: 1
2021-08-18 14:41:25,678 [http-nio-8090-exec-8] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 14:41:25,704 [http-nio-8090-exec-8] ==> Parameters: 1(Long)
2021-08-18 14:41:25,718 [http-nio-8090-exec-8] <==      Total: 1
2021-08-18 14:42:33,680 [http-nio-8090-exec-8] ==>  Preparing: select * from testTreeExample t order by t.sort 
2021-08-18 14:42:33,682 [http-nio-8090-exec-8] ==> Parameters: 
2021-08-18 14:42:33,688 [http-nio-8090-exec-8] <==      Total: 12
2021-08-18 15:19:54,191 [http-nio-8090-exec-4] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 15:19:54,193 [http-nio-8090-exec-4] ==> Parameters: 1(Long)
2021-08-18 15:19:54,196 [http-nio-8090-exec-4] <==      Total: 1
2021-08-18 15:19:59,940 [http-nio-8090-exec-8] ==>  Preparing: select count(1) from oneToMany t 
2021-08-18 15:19:59,940 [http-nio-8090-exec-8] ==> Parameters: 
2021-08-18 15:19:59,944 [http-nio-8090-exec-8] <==      Total: 1
2021-08-18 15:19:59,949 [http-nio-8090-exec-8] ==>  Preparing: select * from oneToMany t order by id asc limit ?, ? 
2021-08-18 15:19:59,950 [http-nio-8090-exec-8] ==> Parameters: 0(Integer), 10(Integer)
2021-08-18 15:19:59,952 [http-nio-8090-exec-8] <==      Total: 4
2021-08-18 15:59:06,128 [http-nio-8090-exec-7] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 15:59:06,149 [http-nio-8090-exec-7] ==> Parameters: 1(Long)
2021-08-18 15:59:06,167 [http-nio-8090-exec-7] <==      Total: 1
2021-08-18 15:59:10,194 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 15:59:10,209 [taskExecutor-1] ==> Parameters: 1(Long), 退出(String), true(Boolean), null
2021-08-18 15:59:10,213 [taskExecutor-1] <==    Updates: 1
2021-08-18 15:59:11,408 [http-nio-8090-exec-10] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-08-18 15:59:11,411 [http-nio-8090-exec-10] ==> Parameters: admin(String)
2021-08-18 15:59:11,417 [http-nio-8090-exec-10] <==      Total: 1
2021-08-18 15:59:11,435 [http-nio-8090-exec-10] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-08-18 15:59:11,436 [http-nio-8090-exec-10] ==> Parameters: 1(Long)
2021-08-18 15:59:11,454 [http-nio-8090-exec-10] <==      Total: 44
2021-08-18 15:59:11,570 [taskExecutor-2] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-08-18 15:59:11,572 [taskExecutor-2] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-08-18 15:59:11,578 [taskExecutor-2] <==    Updates: 1
2021-08-18 15:59:11,836 [http-nio-8090-exec-6] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-08-18 15:59:11,847 [http-nio-8090-exec-6] ==> Parameters: 1(Long)
2021-08-18 15:59:11,854 [http-nio-8090-exec-6] <==      Total: 1
2021-08-18 15:59:20,799 [http-nio-8090-exec-10] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-08-18 15:59:20,799 [http-nio-8090-exec-10] ==> Parameters: 
2021-08-18 15:59:20,814 [http-nio-8090-exec-10] <==      Total: 44
