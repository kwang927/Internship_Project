package com.boot.security.server.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

import com.boot.security.server.filter.TokenFilter;

/**
 * spring security配置
 *
 * @author 小威老师 xiaoweijiagou@163.com
 * <p>
 * 2017年10月16日
 */
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private AuthenticationSuccessHandler authenticationSuccessHandler;
    @Autowired
    private AuthenticationFailureHandler authenticationFailureHandler;
    @Autowired
    private LogoutSuccessHandler logoutSuccessHandler;
    @Autowired
    private AuthenticationEntryPoint authenticationEntryPoint;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private TokenFilter tokenFilter;

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     *  此处只配置需要拦截验证身份的请求url表达式, 不匹配的url默认放行。
     *  url拦截表达式可以配置多个，以达到更细粒度精确控制访问，
     *  但注意：匹配器是按顺序考虑的。因此，以下是无效的，因为第一个匹配器匹配每个请求，永远不会到达第二个映射:
     *  http.authorizeRequests()
     *  .antMatchers("/**").hasRole("USER")
     *  .antMatchers("admin/**").hasRole("ADMIN")
     *  建议按照url表达式的字符串长短对应从上到下顺序配置！
     *  url表达式有精确匹配与模糊匹配。例： /path  /path/*  /path/**
     *
     *  注意：hasAuthority("ROLE_ADMIN")方法与注解 @PreAuthorize("hasAuthority('ROLE_ADMIN')")起到的作用是相同的，不能同时配置
     *  虽然编译运行不会报错，但在发生AccessDeniedException异常时，自定义异常处理方法ExceptionHandlerAdvice#badRequestException(AccessDeniedException)不会被调用。
     *  建议二选一。
     *
     *  hasRole("ADMIN")与hasAuthority("ROLE_ADMIN")作用是相同的，简单理解为只是多了个前缀"ROLE_"。
     *
     * @param httpSecurity
     * @throws Exception
     */
    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception { 
        httpSecurity
                    .headers().frameOptions().disable().and()                                           //解决不允许显示iframe的问题
                    .headers().cacheControl().disable().and()                                           //禁止客户端缓存数据
                    .csrf().disable().cors().disable()                                                                   //或者使用.cors().disable()。 特别是在前后端分离的项目，必须设置支持跨域。等于((HttpServletResponse)response).setHeader("Access-Control-Allow-Origin","*");
                    .authorizeRequests()
                    .antMatchers("/swagger-resources/**","/swagger**","/webjars/**","/favicon.ico","/v2/api-docs**","/druid/**","/statics/**","/mails").permitAll()                                                               //开始配置拦截规则。TokenFilter内会对携带有效jwt请求授予Authentication。
                     .antMatchers(HttpMethod.OPTIONS).permitAll()                    //不拦截Http option方法的的请求
                                        .antMatchers("/**").authenticated();               //拦截所有请求检查 Authentication。 拒绝没有通过认证的请求。(访问某些资源还需要有相应的自定义ROLE权限)
                //    .antMatchers("/**").permitAll(); 
        httpSecurity
                    .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()   //前后端分离的项目不适合使用传统的HttpSession + sessionId + Cookie保持会话，禁用HttpSession，改用JWT。
                    .addFilterBefore(tokenFilter, UsernamePasswordAuthenticationFilter.class)           //配置jwt过滤器。检查并补充每个请求的用户身份与授予的权限。TokenFilter会对携带有效jwt的请求发放一个Authentication。
                    .exceptionHandling().authenticationEntryPoint(authenticationEntryPoint).and()       //虽然配置了全局异常处理类ExceptionHandlerAdvice，但有些情况异常并不会被抛出，而是被默认的ExceptionHandler处理掉，或者交给"/error"映射的ErrorController处理。参考：AccessDeniedHandlerImpl.java:73行 BasicErrorController.java:57行
                    .logout().logoutUrl("/logout").logoutSuccessHandler(logoutSuccessHandler).and()     //自定义退出登录url，默认支持Http post方法。只需要向这个url映射的接口发送一个post请求，不用携带参数。
                    .formLogin()                                                                        //表单登录，默认支持Http post方法,需要携带两个参数（username、password）,security框架会调用UserDetailsService实现类自动处理。
                                .loginProcessingUrl("/login")                                           //自定义登录url
                                .successHandler(authenticationSuccessHandler)                           //登录成功回调
                                .failureHandler(authenticationFailureHandler);                          //登录失败回调
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService).passwordEncoder(bCryptPasswordEncoder());
    }

}





