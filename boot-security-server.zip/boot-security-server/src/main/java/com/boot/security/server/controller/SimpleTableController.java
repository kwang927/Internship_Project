package com.boot.security.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.security.server.page.table.PageTableRequest;
import com.boot.security.server.page.table.PageTableHandler;
import com.boot.security.server.page.table.PageTableResponse;
import com.boot.security.server.page.table.PageTableHandler.CountHandler;
import com.boot.security.server.page.table.PageTableHandler.ListHandler;
import com.boot.security.server.dao.SimpleTableDao;
import com.boot.security.server.model.SimpleTable;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/simpleTables")
public class SimpleTableController {

    @Autowired
    private SimpleTableDao simpleTableDao;

    @PostMapping
    @ApiOperation(value = "保存")
    public SimpleTable save(@RequestBody SimpleTable simpleTable) {
        simpleTableDao.save(simpleTable);

        return simpleTable;
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "根据id获取")
    public SimpleTable get(@PathVariable Long id) {
        return simpleTableDao.getById(id);
    }

    @PutMapping
    @ApiOperation(value = "修改")
    public SimpleTable update(@RequestBody SimpleTable simpleTable) {
        simpleTableDao.update(simpleTable);

        return simpleTable;
    }

    @GetMapping
    @ApiOperation(value = "列表")
    public PageTableResponse list(PageTableRequest request) {
        return new PageTableHandler(new CountHandler() {

            @Override
            public int count(PageTableRequest request) {
                return simpleTableDao.count(request.getParams());
            }
        }, new ListHandler() {

            @Override
            public List<SimpleTable> list(PageTableRequest request) {
                return simpleTableDao.list(request.getParams(), request.getOffset(), request.getLimit());
            }
        }).handle(request);
    }

    @DeleteMapping("/{id}")
    @ApiOperation(value = "删除")
    public void delete(@PathVariable Long id) {
        simpleTableDao.delete(id);
    }
}
