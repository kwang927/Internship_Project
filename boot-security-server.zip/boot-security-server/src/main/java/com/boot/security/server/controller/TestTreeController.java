//package com.boot.security.server.controller;
//
//public class TestTreeController {
//
//}


package com.boot.security.server.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.boot.security.server.service.TestTreeService;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.boot.security.server.annotation.LogAnnotation;
import com.boot.security.server.dao.TestTreeDao;
import com.boot.security.server.model.TestTree;
import com.google.common.collect.Lists;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@Api(tags = "一颗普通的树")
@RestController
@RequestMapping("/testTrees")
public class TestTreeController {

	@Autowired
	private TestTreeDao testTreeDao;
	@Autowired
	private TestTreeService testTreeService;



	/**
	 * 设置子元素
	 * 2018.06.09
	 *
	 * @param p
	 * @param testTrees
	 */
//	private void setChild(TestTree p, List<TestTree> testTrees) {
//		List<TestTree> child = testTrees.parallelStream().filter(a -> a.getParentId().equals(p.getId())).collect(Collectors.toList());
//		p.setChild(child);
//		if (!CollectionUtils.isEmpty(child)) {
//			child.parallelStream().forEach(c -> {
//				//递归设置子元素，多级菜单支持
//				setChild(c, testTrees);
//			});
//		}
//	}



	/**
	 * 菜单列表
	 *
	 * @param pId
	 * @param testTreesAll
	 * @param list
	 */
	private void setTestTreesList(Long pId, List<TestTree> testTreesAll, List<TestTree> list) {
		for (TestTree per : testTreesAll) {
			if (per.getParentId().equals(pId)) {
				list.add(per);
				if (testTreesAll.stream().filter(p -> p.getParentId().equals(per.getId())).findAny() != null) {
					setTestTreesList(per.getId(), testTreesAll, list);
				}
			}
		}
	}

	@GetMapping
	@ApiOperation(value = "菜单列表")
	@PreAuthorize("hasAuthority('sys:menu:query')")
	public List<TestTree> testTreesList() {
		List<TestTree> testTreesAll = testTreeDao.listAll();

		List<TestTree> list = Lists.newArrayList();
		setTestTreesList(0L, testTreesAll, list);

		return list;
	}

	@GetMapping("/all")
	@ApiOperation(value = "所有菜单")
	@PreAuthorize("hasAuthority('sys:menu:query')")
	public JSONArray testTreesAll() {
		List<TestTree> testTreesAll = testTreeDao.listAll();
		JSONArray array = new JSONArray();
		setTestTreesTree(0L, testTreesAll, array);

		return array;
	}

	@GetMapping("/parents")
	@ApiOperation(value = "一级菜单")
	public List<TestTree> parentMenu() {
		List<TestTree> parents = testTreeDao.listParents();

		return parents;
	}

	/**
	 * 菜单树
	 *
	 * @param pId
	 * @param testTreesAll
	 * @param array
	 */
	private void setTestTreesTree(Long pId, List<TestTree> testTreesAll, JSONArray array) {
		for (TestTree per : testTreesAll) {
			if (per.getParentId().equals(pId)) {
				String string = JSONObject.toJSONString(per);
				JSONObject parent = (JSONObject) JSONObject.parse(string);
				array.add(parent);

				if (testTreesAll.stream().filter(p -> p.getParentId().equals(per.getId())).findAny() != null) {
					JSONArray child = new JSONArray();
					parent.put("child", child);
					setTestTreesTree(per.getId(), testTreesAll, child);
				}
			}
		}
	}



	@LogAnnotation
	@PostMapping
	@ApiOperation(value = "保存菜单")
	public void save(@RequestBody TestTree testTree) {
		testTreeDao.save(testTree);
	}

	@GetMapping("/{id}")
	@ApiOperation(value = "根据菜单id获取菜单")
	@PreAuthorize("hasAuthority('sys:menu:query')")
	public TestTree get(@PathVariable Long id) {
		return testTreeDao.getById(id);
	}

	@LogAnnotation
	@PutMapping
	@ApiOperation(value = "修改菜单")
	public void update(@RequestBody TestTree testTree) {
		testTreeService.update(testTree);
	}



	@LogAnnotation
	@DeleteMapping("/{id}")
	@ApiOperation(value = "删除菜单")
	@PreAuthorize("hasAuthority('sys:menu:del')")
	public void delete(@PathVariable Long id) {
		testTreeService.delete(id);
	}
}
