package com.boot.security.server.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.boot.security.server.model.TestTree;

@Mapper
public interface TestTreeDao {

	@Select("select * from testTreeExample t order by t.sort")
	List<TestTree> listAll();

	@Select("select * from testTreeExample t order by t.sort")
	List<TestTree> listParents();

	@Select("select * from testTreeExample t where t.id = #{id}")
	TestTree getById(Long id);

	@Insert("insert into testTreeExample(parentId, name, content, sort) values(#{parentId}, #{name}, #{content}, #{sort})")
	int save(TestTree testTree);

	@Update("update testTreeExample t set parentId = #{parentId}, name = #{name}, content = #{content}, sort = #{sort} where t.id = #{id}")
	int update(TestTree testTree);

	@Delete("delete from testTreeExample where id = #{id}")
	int delete(Long id);

	@Delete("delete from testTreeExample where parentId = #{id}")
	int deleteByParentId(Long id);

	
}
