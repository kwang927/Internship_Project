package com.boot.security.server.model;



public class NewTest extends BaseEntity<Long> {

	private Integer userId;
	private String sub;

	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}

}
