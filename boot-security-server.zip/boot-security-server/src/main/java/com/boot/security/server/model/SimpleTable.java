package com.boot.security.server.model;



public class SimpleTable extends BaseEntity<Long> {

	private String content;
	private String sub;

	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSub() {
		return sub;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}

}
