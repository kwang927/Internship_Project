//package com.boot.security.server.model;
//
//public class TestTree {
//
//}


package com.boot.security.server.model;

import java.util.List;

public class TestTree extends BaseEntity<Long> {

	private static final long serialVersionUID = 2333L;

	private Long parentId;
	private String name;
	private String content;

	private Integer sort;

	private List<TestTree> child;

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}

	

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public List<TestTree> getChild() {
		return child;
	}

	public void setChild(List<TestTree> child) {
		this.child = child;
	}
}
