//package com.boot.security.server.service;
//
//public interface TestTreeService {
//
//}

package com.boot.security.server.service;

import com.boot.security.server.model.TestTree;

public interface TestTreeService {

	void save(TestTree testTree);

	void update(TestTree testTree);

	void delete(Long id);
}

