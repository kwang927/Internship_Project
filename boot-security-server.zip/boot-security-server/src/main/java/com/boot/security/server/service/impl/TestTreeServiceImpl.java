//package com.boot.security.server.service.impl;
//
//public class TestTreeServiceImpl {
//
//}


package com.boot.security.server.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.boot.security.server.dao.TestTreeDao;
import com.boot.security.server.model.TestTree;
import com.boot.security.server.service.TestTreeService;

@Service
public class TestTreeServiceImpl implements TestTreeService {

//	private static final Logger log = LoggerFactory.getLogger("adminLogger");

	@Autowired
	private TestTreeDao testTreeDao;

	@Override
	public void save(TestTree permission) {
		testTreeDao.save(permission);

//		log.debug("新增菜单{}", permission.getName());
	}

	@Override
	public void update(TestTree testTree) {
		testTreeDao.update(testTree);
	}

	@Override
	@Transactional
	public void delete(Long id) {
		testTreeDao.delete(id);
		testTreeDao.deleteByParentId(id);

//		log.debug("删除菜单id:{}", id);
	}

}
